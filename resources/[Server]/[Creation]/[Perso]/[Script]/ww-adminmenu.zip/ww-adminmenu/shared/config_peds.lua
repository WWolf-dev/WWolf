Peds = {
    {
        label = "Reset",
        model = "restore"
    },
    {
        label = "Beach Lady",
        model = "a_f_m_beach_01"
    },
    {
        label = "Fat Lady",
        model = "a_f_m_fatbla_01"
    },
    {
        label = "Naked Man",
        model = "a_m_m_acult_01"
    },
}